# Função para separar números pares e ímpares em listas diferentes
def separar_pares_impares(valores):
    pares = []
    impares = []
    for valor in valores:
        if valor % 2 == 0:
            pares.append(valor)
        else:
            impares.append(valor)
    return pares, impares

# Função para calcular a soma de uma lista de números
def calcular_soma(valores):
    return sum(valores)

# Função principal
def main():
    # Solicitar ao usuário para digitar 10 valores
    print("Digite 10 valores:")
    valores = []
    for i in range(10):
        valor = int(input(f"Digite o {i+1}º valor: "))
        valores.append(valor)

    # Separar os números pares e ímpares em listas diferentes
    pares, impares = separar_pares_impares(valores)

    # Exibir os números pares
    print("\nNúmeros pares:")
    for num in pares:
        print(num, end=" ")

    # Exibir os números ímpares em uma tupla
    print("\nNúmeros ímpares em uma tupla:")
    print(tuple(impares))

    # Calcular e exibir a quantidade de números pares e ímpares
    qtde_pares = len(pares)
    qtde_impares = len(impares)
    print("\nQuantidade de números pares:", qtde_pares)
    print("Quantidade de números ímpares:", qtde_impares)

    # Calcular e exibir a soma de todos os números pares e ímpares
    soma_pares = calcular_soma(pares)
    soma_impares = calcular_soma(impares)
    print("Soma dos números pares:", soma_pares)
    print("Soma dos números ímpares:", soma_impares)

if __name__ == "__main__":
    main()
